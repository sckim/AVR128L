#include <avr/io.h>
#include <util/delay.h>

typedef unsigned char Byte;

void Initialize_Ports(void)
{
	DDRA = 0xFF;
	DDRB = 0xFF;
	DDRC = 0xFF;
	DDRD = 0xFE;
	DDRE = 0xFF;
	DDRF = 0xFF;
}

int main (void)
{
	Byte LED[8] = {0xFE,0xFC,0xF8,0xF0,0xE0,0xC0,0x80,0x00};
	Byte SEG[10]= {0XC0, 0XF9,0XA4,0XB0,0X99,0X92,0X82, 0XD8,0X80,0X90};

	signed char Index = 0;
	unsigned char flag = 1;
	
	Initialize_Ports();

	PORTA = 0xFF; // B��Ʈ�� ���Ͽ� 1111,1111 ��� (LED Off ��)

	while (1)  // ���ѷ��� ����
	{
		PORTA = LED[Index];
		PORTF = ~SEG[Index+1];
		
		if (flag)
			Index++;
		else
			Index--;

		if(Index == 7 || Index==0 ) flag^=1;

		_delay_ms(1000);  // 500ms ������Ŵ
	}
}
